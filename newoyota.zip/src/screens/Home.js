import React, { useState } from "react";

import WelcomeScreen from "../components/UI/WelcomeScreen";
import logo from "../assets/logo.jpg";
import styles from "./styles.module.css";

const Home = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  return (
    <div className={styles.app}>
      <div className={styles.grid}>
        <WelcomeScreen />
        <div className={styles.forms}>
          <div className={styles.logo}>
            <img src={logo} alt="Toyota Logo" />
          </div>
          <h6 className="text-center " style={{ padding: ".5rem" }}>
            Welcome Back!
          </h6>
          <form>
            <div className="row">
              <div className={`${styles.formPadding} col-md-12`}>
                <label>Email Address</label>
                <input
                  type="email"
                  className="form-control"
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter Email"
                />
              </div>
              <div className={`${styles.formPadding} col-md-12`}>
                <label>Password</label>
                <input
                  type="password"
                  className="form-control"
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter Password"
                />
              </div>
              <div className={`${styles.formPadding} col-md-12`}>
                <label />
                <input
                  type="submit"
                  className="form-control btn btn-danger"
                  value="Login"
                />
                <p className="text-center">
                  <br />
                  <small>&copy;2021 Copyrights All Rights & Reserved</small>
                </p>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Home;
