import React from "react";
import Location from "../../components/Location";
import Navigation from "../../components/Navigation";
import Navbar from "../../components/Navigation/Navbar";
import styles from "../styles.module.css";

const VideoFolder = () => {
  return (
    <div className={styles.app}>
      <Navbar />
      <div className={styles.appGrid}>
        <Navigation />
        <div className={styles.content}>
          <Location name="Lekki" />
          <Location name="Apapa" />
        </div>
      </div>
    </div>
  );
};

export default VideoFolder;
