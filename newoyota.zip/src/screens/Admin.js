import React, { useState } from "react";
import Navigation from "../components/Navigation";
import Navbar from "../components/Navigation/Navbar";
import { Link } from "react-router-dom";
import styles from "./styles.module.css";

const Admin = () => {
  const [fname, setFname] = useState("");
  const [lname, setLname] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmpassword, setConfirmPassword] = useState("");
  const [location, setLocation] = useState("");
  return (
    <div className={styles.app}>
      <Navbar />
      <div className={styles.appGrid}>
        <Navigation />

        <div className={styles.forms}>
          <div className={`${styles.formPadding} col-md-3`}>
            <Link to="/" className={`btn form-control btn-warning`}>
              View Users
            </Link>
          </div>
          <form>
            <div className="row">
              <div className={`${styles.formPadding} col-md-4`}>
                <label>First Name</label>
                <input
                  type="text"
                  className="form-control"
                  onChange={(e) => setFname(e.target.value)}
                  placeholder="Enter Firstname"
                />
              </div>
              <div className={`${styles.formPadding} col-md-4`}>
                <label>Last Name</label>
                <input
                  type="text"
                  className="form-control"
                  onChange={(e) => setLname(e.target.value)}
                  placeholder="Enter Firstname"
                />
              </div>

              <div className={`${styles.formPadding} col-md-4`}>
                <label>Email Address</label>
                <input
                  type="email"
                  className="form-control"
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter Email"
                />
              </div>
              <div className={`${styles.formPadding} col-md-4`}>
                <label>Password</label>
                <input
                  type="password"
                  className="form-control"
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter Password"
                />
              </div>
              <div className={`${styles.formPadding} col-md-4`}>
                <label>Confirm Password</label>
                <input
                  type="password"
                  className="form-control"
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Confirm Password"
                />
              </div>
              <div className={`${styles.formPadding} col-md-4`}>
                <label>Location</label>
                <input
                  type="text"
                  className="form-control"
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="Select Location"
                />
              </div>
              <div className={`${styles.formPadding} col-md-4`}>
                <label />
                <input
                  type="submit"
                  className="form-control btn btn-danger"
                  onChange={(e) => setLocation(e.target.value)}
                  value="Add User"
                />
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Admin;
