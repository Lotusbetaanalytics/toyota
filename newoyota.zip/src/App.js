import React from "react";
import { BrowserRouter as Router, Route } from "react-router-dom";
import Admin from "./screens/Admin";
import Dashboard from "./screens/Dashboard";
import Home from "./screens/Home";
import VideoFolder from "./screens/Videos";

function App() {
  return (
    <>
      <Router>
        <Route path="/" exact component={Home} />
        <Route path="/dashboard" exact component={Dashboard} />
        <Route path="/videos" exact component={VideoFolder} />
        <Route path="/admin" exact component={Admin} />
      </Router>
    </>
  );
}

export default App;
