import React from 'react'
import { Link } from 'react-router-dom'
import { FaThLarge, FaCamera, FaUserCircle, FaSignOutAlt } from "react-icons/fa";

import styles from './styles.module.css'

const Navigation = () => {
    return (
        <div className={styles.navigation}>

            <ul>
                <Link to="/dashboard"><li className="text-center"><FaThLarge /> Dashboard</li></Link>
                <Link to="/videos"><li className="text-center"><FaCamera /> Videos</li> </Link>
                <Link to="/admin"><li className="text-center"><FaUserCircle /> Admin</li></Link>
                <Link to="/dashboard"><li className="text-center"><FaSignOutAlt />Logout</li></Link>
            </ul>
        </div>
    )
}

export default Navigation
